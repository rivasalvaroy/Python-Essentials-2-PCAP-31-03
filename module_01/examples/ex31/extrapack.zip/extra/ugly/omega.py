#! /usr/bin/env python3

""" module: omega """


def funA():
    return "Omega"


if __name__ == "__main__":
    print("Yo prefiero ser un módulo")
